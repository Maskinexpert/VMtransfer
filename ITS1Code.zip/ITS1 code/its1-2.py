from scapy.all import *

ports = [21,22,23,25,80,110,139,443,445,3389,631]
SYNACK = 0x12

def scanport(port):
	srcport = RandShort()
	conf.verb=0
	conf.L3socket=L3RawSocket
	SYNACKpkt = sr1(IP(dst="localhost")/TCP(sport = srcport, dport = port, flags="S"))
	pktflags = SYNACKpkt.getlayer(TCP).flags
	if pktflags == SYNACK:
		return True
	else:
		return False
	
for port in ports:
	status = scanport(port)
	if status == True:
		print "Port " + str(port) + " open"
	else:
		print "Port " + str(port) + " closed"
