from scapy.all import *
conf.verb=0
conf.L3socket=L3RawSocket

packet = IP(dst="localhost")/ICMP()
reply = sr1(packet)
if reply:
        reply.show()
