<!DOCTYPE html>
<html>
<body>

<h1>The press room</h1>

<p>Click on a press release from the archive.<br>

<ul>
<li><a href="pressroom2.php?rel=11-02-2017.html">February 2017</a></li>
<li><a href="pressroom2.php?rel=09-04-2017.html">April 2017</a></li>
</ul>
</p>

<?php
ini_set("error_log", getcwd()."/error.log");
$release = $_REQUEST['rel'];

if (empty($release))
{
  exit();
}
else
{
  echo "<p><hr></p>";
  switch ($release) {
    case "09-04-2017.html":
        echo "You requested " . $release . "<br>";
        include $release;
	break;
    case "11-02-2017.html":
        echo "You requested " . $release . "<br>";
        include $release;
	break;
    default:
        echo "Release not found: " . $release;
        break;
 }
}
?>

</body>
</html>
